# Progress

| Milestone | Status | Notes |
|---|---|---|
| M1 Skeleton and data pipeline | not started | |
| M2 All P0 indicators fetched and verified | not started | |
| M3 Design system and design preview | not started | |
| M4 Homepage | not started | |
| M5 Indicator page and compare module | not started | |
| M6 Area and subsection pages | not started | |
| M7 P1 indicators, Sources, About, How to read, states | not started | |
| M8 Quality checks and Bangla review | not started | |
| M9 Launch and scheduled refresh | not started | |

## Open questions for Ahmar
(none yet)
